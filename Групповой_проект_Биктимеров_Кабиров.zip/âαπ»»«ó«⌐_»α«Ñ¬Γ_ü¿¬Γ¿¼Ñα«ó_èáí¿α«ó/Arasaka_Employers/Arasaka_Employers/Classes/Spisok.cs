﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Arasaka_Employers.Classes
{
    public class Spisok
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public int Count { get; set; }
        public int cost { get; set; }
    }
}
