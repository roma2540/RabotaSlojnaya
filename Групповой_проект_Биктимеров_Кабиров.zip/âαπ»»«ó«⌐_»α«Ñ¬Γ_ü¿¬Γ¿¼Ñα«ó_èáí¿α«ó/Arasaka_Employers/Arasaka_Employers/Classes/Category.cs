﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Arasaka_Employers.Classes
{
    public class Category
    {
        public string Name { get; set; }
    }
}
