﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Arasaka_Employers.Classes
{
    internal class MyLists
    {
       public static List<Spisok> spisoks = new List<Spisok>();
    }
}
