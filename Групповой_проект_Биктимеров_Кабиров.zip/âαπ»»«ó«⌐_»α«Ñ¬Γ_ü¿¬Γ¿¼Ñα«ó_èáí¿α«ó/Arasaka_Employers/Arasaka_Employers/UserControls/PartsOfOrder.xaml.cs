﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;

namespace Arasaka_Employers.UserControls
{
    /// <summary>
    /// Логика взаимодействия для PartsOfOrder.xaml
    /// </summary>
    public partial class PartsOfOrder : UserControl
    {
        private MySqlConnection con;
        private int ID_product;
        public PartsOfOrder(int id)
        {
            con = new MySqlConnection(App.conString);
            InitializeComponent();
            con.Open();
            var appDir = System.IO.Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
            string Querry = $"Select ID_Product,Conut from order_product where idOrder_product={id}";
            MySqlCommand command = new MySqlCommand(Querry, con);
            MySqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                ID_product=reader.GetInt32(0);
                Count.Text = reader.GetString(1);
            }
            con.Close();
            con.Open();
            string Querry2 = $"Select Name_product,photo from products where Id_product={ID_product}";
            MySqlCommand command2 = new MySqlCommand(Querry2, con);
            MySqlDataReader reader2 = command2.ExecuteReader();
            while (reader2.Read())
            {
               Name.Text = reader2.GetString(0);
               img.Source = new BitmapImage(new Uri(appDir + $"\\{System.IO.Path.GetFileName(reader2[1].ToString())}", UriKind.RelativeOrAbsolute));
            }
            con.Close();

        }
    }
}
