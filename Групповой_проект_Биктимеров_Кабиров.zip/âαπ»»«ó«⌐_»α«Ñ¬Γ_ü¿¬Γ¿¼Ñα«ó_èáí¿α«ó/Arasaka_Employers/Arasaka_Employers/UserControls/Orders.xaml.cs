﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;
using Arasaka_Employers.Windows;
namespace Arasaka_Employers.UserControls
{
    /// <summary>
    /// Логика взаимодействия для Orders.xaml
    /// </summary>
    public partial class Orders : UserControl
    {
        private MySqlConnection con;
        private int id_user;
        private int id_status;
        private int id_order;
        public Orders(int id)
        {
            InitializeComponent();
            id_order = id;
            string Querry = $"Select * from orders where ID_Order={id}";
            con = new MySqlConnection(App.conString);
            con.Open();
            MySqlCommand command = new MySqlCommand(Querry, con);
            MySqlDataReader reader = command.ExecuteReader();
            while (reader.Read()) 
            {
                IDOrder.Text = reader.GetString(0);
                //Date.Text = Convert.ToString(reader[1]);
                id_user = reader.GetInt32(2);
                id_status = reader.GetInt32(3);
            }
            con.Close();
            con.Open();
            string Querry2 = $"Select Name,Surname,Patronymic from users where Id_User={id_user}";
            MySqlCommand command2 = new MySqlCommand(Querry2, con);
            MySqlDataReader reader2 = command2.ExecuteReader();
            while (reader2.Read())
            {
                Id_user.Text = reader2.GetString(0) + " " + reader2.GetString(1) + " " + reader2.GetString(2);
            }
            con.Close();
            con.Open();
            string Querry3 = $"Select * from status where idstatus={id_status}";
            MySqlCommand command3 = new MySqlCommand(Querry3, con);
            MySqlDataReader reader3 = command3.ExecuteReader();
            while (reader3.Read())
            {
               Status.Text=reader3.GetString(1);
            }
            con.Close();

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            InfoToOrder info = new InfoToOrder(id_order);
            info.Show();
        }
    }
}
