﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;
namespace Arasaka_Employers.UserControls
{
    /// <summary>
    /// Логика взаимодействия для Users.xaml
    /// </summary>
    public partial class Users : UserControl
    {
        private MySqlConnection con;
        private int role;
        public Users(int id)
        {
            InitializeComponent();
            con = new MySqlConnection(App.conString);
            con.Open();
            string querry = $"Select * from users where Id_User={id}";
            MySqlCommand command = new MySqlCommand(querry, con);
            MySqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
               UName.Text = reader.GetString(1);
               USurname.Text = reader.GetString(2);
               Patronymic.Text = reader.GetString(3);
               Login.Text = reader.GetString(4);
                role = reader.GetInt32(6);
            }
            con.Close();
            con.Open();
            string querry1 = "Select * from roles";
            MySqlCommand command1 = new MySqlCommand(querry1, con);
            MySqlDataReader reader1 = command1.ExecuteReader();
            while (reader1.Read()) 
            {
                if (reader1.GetInt32(0) == role)
                {
                    Role.Text = reader1.GetString(1);
                }
            }
        }
    }
}
