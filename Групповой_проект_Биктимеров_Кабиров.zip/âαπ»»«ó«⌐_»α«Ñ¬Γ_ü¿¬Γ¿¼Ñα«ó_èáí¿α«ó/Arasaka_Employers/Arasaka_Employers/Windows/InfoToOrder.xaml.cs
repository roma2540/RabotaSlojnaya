﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Arasaka_Employers.UserControls;

namespace Arasaka_Employers.Windows
{
    /// <summary>
    /// Логика взаимодействия для InfoToOrder.xaml
    /// </summary>
    public partial class InfoToOrder : Window
    {
        private MySqlConnection con;
        public InfoToOrder(int id)
        {
            con = new MySqlConnection(App.conString);
            InitializeComponent();
            con.Open();
            string Querry = $"Select idOrder_product from order_product where Id_order={id}";
            MySqlCommand command = new MySqlCommand(Querry, con);
            MySqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                Vitrina.Items.Add(new PartsOfOrder(Convert.ToInt32(reader[0])));
            }
            con.Close();
        }
    }
}
