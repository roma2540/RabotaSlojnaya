﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;
using Arasaka_Employers.Classes;
using Microsoft.Win32;
using System.Reflection;
using System.IO;

namespace Arasaka_Employers.Pages
{
    /// <summary>
    /// Логика взаимодействия для CreateTovar.xaml
    /// </summary>
    public partial class CreateTovar : Page
    {
        MySqlConnection con;
        private List<Category> categories  = new List<Category>();
        private int? _id;
        private string phut;
        private string photoName;
        public CreateTovar(int? id)
        {
            
            con= new MySqlConnection(App.conString);
            InitializeComponent();
            AddCategoryToCB();

            if (id != null)
            {
                _id = id;
                var appDir = System.IO.Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
                con.Open();
                string querry = $"Select * from products where Id_product='{id}'";                
                MySqlCommand mySql = new MySqlCommand(querry, con);
                MySqlDataReader dr = mySql.ExecuteReader();
                while (dr.Read()) 
                {
                    NameTovar.Text = dr[1].ToString();
                    Opisanie.Text = dr[2].ToString();
                    Cost.Text = dr[4].ToString();
                    Count.Text = dr[5].ToString();
                    img.Source = new BitmapImage(new Uri(appDir + $"\\{System.IO.Path.GetFileName(dr[6].ToString())}", UriKind.RelativeOrAbsolute));
                }
                con.Close();
            }
            NameTovar.MaxLength = 100;
            Opisanie.MaxLength = 600;
        }
        private void AddCategoryToCB() 
        {
            string querry = "Select * from categorys";
            con.Open();
            MySqlCommand mySqlCommand = new MySqlCommand(querry, con);
            MySqlDataReader dataReader = mySqlCommand.ExecuteReader();
            while (dataReader.Read())
            {
                categories.Add(new Category { Name = dataReader[1].ToString()});
            }
            this.Category.ItemsSource = categories;
            con.Close();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        { if (NameTovar.Text!="" && Opisanie.Text!="" && Cost.Text!=""&& Count.Text!="" && Category.Text!="")
            {
                if (_id == null)
                {
                    if (photoName != null) {
                        con.Open();
                        string querry = $"INSERT INTO products(Name_product,Description,Category,Cost,Count_product,photo) VALUES('{NameTovar.Text}','{Opisanie.Text}',{Category.SelectedIndex + 1},{Convert.ToInt32(Cost.Text)},{Convert.ToInt32(Count.Text)},'{photoName}.png');";
                        MySqlCommand mySql = new MySqlCommand(querry, con);
                        mySql.ExecuteNonQuery();
                        con.Close();
                        ClearAllStr();
                        MessageBox.Show("Добавлен");
                    }
                    else
                    {
                        MessageBox.Show("Выбери фото");
                    }
                }
                else
                {
                    con.Open();
                    string querry = $"UPDATE products SET Name_product='{NameTovar.Text}',Description='{Opisanie.Text}',Category={Category.SelectedIndex + 1},Cost={Convert.ToInt32(Cost.Text)},Count_product={Convert.ToInt32(Count.Text)},photo='{photoName}.png'WHERE Id_product={_id}";
                    MySqlCommand mySql = new MySqlCommand(querry, con);
                    mySql.ExecuteNonQuery();
                    con.Close();
                    ClearAllStr();
                    MessageBox.Show("Обновлен");
                }
            }
            else 
            {
                MessageBox.Show("Заполните поля");
            }
        }
        private void ClearAllStr() 
        {
            NameTovar.Text = "";
            Opisanie.Text = "";
            Category.Text = "";
            Cost.Text = "";
            Count.Text = "";
            photoName = "";
        }

        private void Button_Click_2(object sender, RoutedEventArgs e) // выбр фото
        {
            OpenFileDialog dlg = new OpenFileDialog();
            //dlg.DefaultExt = ".png";
            //dlg.Filter = "PNG Files (.png)|.png|JPG Files (.jpg)|.jpg|GIF Files (.gif)|.gif";
            Nullable<bool> result = dlg.ShowDialog();
            if (result == true)
            {
                phut = dlg.FileName;
                var appDir = System.IO.Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + $"\\{System.IO.Path.GetFileName(dlg.FileName)}";
                File.Move(phut, appDir);
                MessageBox.Show("Фото перенесено");
                photoName = System.IO.Path.GetFileNameWithoutExtension(dlg.FileName);
                img.Source = new BitmapImage(new Uri(appDir , UriKind.RelativeOrAbsolute));
            }
        }

        private void Cost_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Space)
            {
                e.Handled = true;
            }
        }

        private void Count_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Space)
            {
                e.Handled = true;
            }
        }

        private void Cost_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (!Char.IsDigit(e.Text, 0))
            {
                e.Handled = true;
            }
            else
            {
                e.Handled = false;
            }
        }

        private void Count_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (!Char.IsDigit(e.Text, 0))
            {
                e.Handled = true;
            }
            else
            {
                e.Handled = false;
            }
        }
    }
}
