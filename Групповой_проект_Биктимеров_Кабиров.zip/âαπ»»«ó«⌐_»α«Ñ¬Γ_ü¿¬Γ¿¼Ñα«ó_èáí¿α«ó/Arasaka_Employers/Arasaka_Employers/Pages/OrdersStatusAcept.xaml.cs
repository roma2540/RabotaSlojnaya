﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Arasaka_Employers.UserControls;

namespace Arasaka_Employers.Pages
{
    /// <summary>
    /// Логика взаимодействия для OrdersStatusAcept.xaml
    /// </summary>
    public partial class OrdersStatusAcept : Page
    {
        private MySqlConnection con;
        public OrdersStatusAcept()
        {
            InitializeComponent();
            con = new MySqlConnection(App.conString);
            AddOrd();
        }
        private void AddOrd()
        {
            string Querry = "Select ID_Order from orders";
            con.Open();
            MySqlCommand command = new MySqlCommand(Querry, con);
            MySqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                Vitrina.Items.Add(new Orders(reader.GetInt32(0)));
            }
            con.Close();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            string Querry = $"UPDATE orders SET Status=2 Where ID_Order={Vitrina.SelectedIndex+1} And Status=1";
            con.Open();
            MySqlCommand command = new MySqlCommand(Querry, con);
            command.ExecuteNonQuery();
            con.Close();
            Vitrina.Items.Clear();
            AddOrd();
        }
    }
}
