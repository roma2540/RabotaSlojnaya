﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Arasaka_Employers.Pages
{
    /// <summary>
    /// Логика взаимодействия для CreateUsers.xaml
    /// </summary>
    public partial class CreateUsers : Page
    {
        List<Role> roles = new List<Role>();
        MySqlConnection con;
        private int? Id;
        public CreateUsers(int? id)
        {
            Id = id;
            InitializeComponent();
            AddCategoryToCB();
            if(id != null)
            {
                string querry = $"Select * from users where Id_User ={id}";
                con.Open();
                MySqlCommand mySqlCommand = new MySqlCommand(querry, con);
                MySqlDataReader dataReader = mySqlCommand.ExecuteReader();
                while (dataReader.Read())
                {
                    Name.Text = dataReader[1].ToString();
                    Surname.Text = dataReader[2].ToString();
                    Patronymic.Text = dataReader[3].ToString();
                    Login.Text = dataReader[4].ToString();
                    Password.Text = dataReader[5].ToString();                    
                }
                con.Close();
            }
            Name.MaxLength = 50;
            Surname.MaxLength = 50;
            Patronymic.MaxLength = 50;
            Login.MaxLength = 50;
            Password.MaxLength = 50;
        }
        private void AddCategoryToCB()
        {
            con = new MySqlConnection(App.conString);
            string querry = "Select * from roles";
            con.Open();
            MySqlCommand mySqlCommand = new MySqlCommand(querry, con);
            MySqlDataReader dataReader = mySqlCommand.ExecuteReader();
            while (dataReader.Read())
            {
                roles.Add(new Role { Name = dataReader[1].ToString() });
            }
            this.Role.ItemsSource = roles;
            con.Close();
        }
        private void ClearAllStr()
        {
            Name.Text = "";
            Surname.Text = "";
            Patronymic.Text = "";
            Login.Text = "";
            Password.Text = "";
            Role.Text = "";
        }

        private void Button_Click(object sender, RoutedEventArgs e) //save
        {
            if (Name.Text!=""&& Surname.Text!=""&& Login.Text!=""&&Password.Text!=""&& Role.Text!="") {
                if (Id == null)
                {
                    con.Open();
                    string querry = $"INSERT INTO users(Name,Surname,Patronymic,Login,Password,Role) VALUES('{Name.Text}','{Surname.Text}','{Patronymic.Text}','{Login.Text}','{Password.Text}',{Role.SelectedIndex + 1})";
                    MySqlCommand mySqlCommand = new MySqlCommand(querry, con);
                    mySqlCommand.ExecuteNonQuery();
                    con.Clone();
                    ClearAllStr();
                    MessageBox.Show("Пользователь добавлен");
                }
                else
                {
                    con.Open();
                    string querry = $"UPDATE users SET Name='{Name.Text}',Surname='{Surname.Text}',Patronymic='{Patronymic.Text}',Login='{Login.Text}',Password='{Password.Text}',Role={Role.SelectedIndex + 1}  WHERE Id_User={Convert.ToInt32(Id)}";
                    MySqlCommand mySqlCommand = new MySqlCommand(querry, con);
                    mySqlCommand.ExecuteNonQuery();
                    con.Clone();
                    ClearAllStr();
                    MessageBox.Show("Пользователь update");
                }
            }
            else 
            {
                MessageBox.Show("Заполните поля");
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }

        private void Name_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Space)
            {
                e.Handled = true;
            }
        }

        private void Surname_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Space)
            {
                e.Handled = true;
            }
        }

        private void Patronymic_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Space)
            {
                e.Handled = true;
            }
        }

        private void Login_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Space)
            {
                e.Handled = true;
            }
        }

        private void Password_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Space)
            {
                e.Handled = true;
            }
        }

        private void Name_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (Char.IsDigit(e.Text, 0))
            {
                e.Handled = true;
            }
            else
            {
                e.Handled = false;
            }
        }

        private void Surname_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (Char.IsDigit(e.Text, 0))
            {
                e.Handled = true;
            }
            else
            {
                e.Handled = false;
            }
        }

        private void Patronymic_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (Char.IsDigit(e.Text, 0))
            {
                e.Handled = true;
            }
            else
            {
                e.Handled = false;
            }
        }

        private void Login_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (Char.IsDigit(e.Text, 0))
            {
                e.Handled = true;
            }
            else
            {
                e.Handled = false;
            }
            
        }

        private void Password_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (Char.IsDigit(e.Text, 0))
            {
                e.Handled = true;
            }
            else
            {
                e.Handled = false;
            }
            
        }
    }
    class Role 
    { 
        public string Name { get; set; }
    }
}
