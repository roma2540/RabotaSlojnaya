﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;
using Arasaka_Employers.UserControls;
namespace Arasaka_Employers.Pages
{
    /// <summary>
    /// Логика взаимодействия для Employees.xaml
    /// </summary>
    public partial class Employees : Page
    {
        private MySqlConnection con;
        List<Users> users = new List<Users>(); 
        public Employees()
        {
            InitializeComponent();
            con = new MySqlConnection(App.conString);
            con.Open();
            string querry = "Select * from users";
            MySqlCommand command = new MySqlCommand(querry, con);
            MySqlDataReader reader = command.ExecuteReader();
            while(reader.Read())
            {
                Vitrina.Items.Add(new Users(Convert.ToInt32(reader[0])));   
            }
            con.Close();
            
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new CreateUsers(null));
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new CreateUsers(Vitrina.SelectedIndex+1));
        }
    }
    
}
