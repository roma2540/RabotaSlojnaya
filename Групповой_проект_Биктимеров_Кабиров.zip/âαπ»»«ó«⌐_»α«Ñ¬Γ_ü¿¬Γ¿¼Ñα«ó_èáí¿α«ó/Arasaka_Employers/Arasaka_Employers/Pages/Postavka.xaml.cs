﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;
using Arasaka_Employers.UserControls;
using Arasaka_Employers.Classes;
using Word = Microsoft.Office.Interop.Word;
namespace Arasaka_Employers.Pages
{
    /// <summary>
    /// Логика взаимодействия для Postavka.xaml
    /// </summary>
    public partial class Postavka : Page
    {

        List<DocDb> docs = new List<DocDb>();
        MySqlConnection con;
        private int Id;
        private int Id_D;
        public Postavka(int id)
        {
            Id = id;
            con = new MySqlConnection(App.conString);
            InitializeComponent();
            AddTovar();

        }
        private void AddTovar()
        {
            con.Open();
            string qweryy = "Select Id_product from products";
            MySqlCommand cmd = new MySqlCommand(qweryy, con);
            MySqlDataReader mySqlDataReader = cmd.ExecuteReader();
            while (mySqlDataReader.Read())
            {
                TavarPost tavarPost = new TavarPost(this, mySqlDataReader.GetInt32(0));
                tavarPost.view = this.Spisok;
                Vitrina.Items.Add(tavarPost);
            }
            con.Close();
        }

        private void Button_Click(object sender, RoutedEventArgs e) 
        {
            NavigationService.GoBack();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e) 
        {
            if (Spisok.Items.Count!=0) {
                UpdateprodPost();
                CreateDocPost();
            }
            else
            {
                MessageBox.Show("Выберите хотя бы один товар","Ошибка");
            }
        }
       
        
       
        private void UpdateprodPost() 
        {
          
                foreach (var items in MyLists.spisoks)
                {
                    con.Open();
                    string querry = $"UPDATE products SET Count_product =Count_product+{items.Count} WHERE Id_product = {items.ID}";
                    MySqlCommand mySqlCommand = new MySqlCommand(querry, con);
                    mySqlCommand.ExecuteNonQuery();
                    con.Close();
                    
                }

               
        }
        
     
        private void CreateDocPost() 
        {
            int sumCost = 0;
            int sumCount = 0;
            
            var application = new Word.Application();
            application = new Word.Application();
            Word.Document document = application.Documents.Add();

            Word.Paragraph paragraph = document.Paragraphs.Add();
            Word.Range range = paragraph.Range;
            range.Text = ($"Поставка                                                                                                       Оформлена:{DateTime.Today}");
            range.InsertParagraphAfter();          

            Word.Paragraph paragraph1 = document.Paragraphs.Add();

            Word.Paragraph table = document.Paragraphs.Add();
            Word.Range tableReng = table.Range;
            tableReng.InsertParagraphAfter();
            Word.Table tables = document.Tables.Add(tableReng, MyLists.spisoks.Count() + 3, 4);
            tables.Borders.InsideLineStyle = tables.Borders.OutsideLineStyle = Word.WdLineStyle.wdLineStyleSingle;
            tables.Range.Cells.VerticalAlignment = Word.WdCellVerticalAlignment.wdCellAlignVerticalCenter;
            Word.Range CellRanges;
            CellRanges = tables.Cell(1, 1).Range;
            CellRanges.Text = "Артикул";
            CellRanges = tables.Cell(1, 2).Range;
            CellRanges.Text = "Наименование";
            CellRanges = tables.Cell(1, 3).Range;
            CellRanges.Text = "Цена за единицу товара";
            CellRanges = tables.Cell(1, 4).Range;
            CellRanges.Text = "Количество";
            tables.Rows[1].Range.Bold = 1;
            tables.Rows[1].Range.ParagraphFormat.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;
            for (int i = 0; i < MyLists.spisoks.Count(); i++)
            {
                var chek = MyLists.spisoks[i];
                CellRanges = tables.Cell(i + 2, 1).Range;
                CellRanges.Text = Convert.ToString(chek.ID);
                CellRanges = tables.Cell(i + 2, 2).Range;
                CellRanges.Text = chek.Name;
                CellRanges = tables.Cell(i + 2, 3).Range;
                CellRanges.Text = Convert.ToString(Convert.ToInt32(chek.cost) + " руб.");
                CellRanges = tables.Cell(i + 2, 4).Range;
                CellRanges.Text = Convert.ToString(chek.Count) + " шт.";
                sumCost += chek.cost * chek.Count;
                sumCount += chek.Count;
            }
            CellRanges = tables.Cell(MyLists.spisoks.Count() + 2, 1).Range;
            CellRanges.Text = "Общая стоймость:";
            CellRanges = tables.Cell(MyLists.spisoks.Count() + 3, 1).Range;
            CellRanges.Text = "Общее количество:";
            CellRanges = tables.Cell(MyLists.spisoks.Count() + 2, 2).Range;
            CellRanges.Text = Convert.ToString(Convert.ToInt32(sumCost) + " руб.");
            CellRanges = tables.Cell(MyLists.spisoks.Count() + 3, 2).Range;
            CellRanges.Text = Convert.ToString(sumCount + " шт.");

            tables.Cell(MyLists.spisoks.Count() + 3, 3).Delete();
            tables.Cell(MyLists.spisoks.Count() + 3, 3).Delete();
            tables.Cell(MyLists.spisoks.Count() + 2, 3).Delete();
            tables.Cell(MyLists.spisoks.Count() + 2, 3).Delete();



            application.Visible = true;

            document.SaveAs($"Postavka.docx");
            MyLists.spisoks.Clear();
            Spisok.Items.Clear();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new OrdersStatusAcept());
        }
    }
    public class DocDb 
    {
        public int id;
        public string name;
        public int cost;
        public int count;
    }
}
