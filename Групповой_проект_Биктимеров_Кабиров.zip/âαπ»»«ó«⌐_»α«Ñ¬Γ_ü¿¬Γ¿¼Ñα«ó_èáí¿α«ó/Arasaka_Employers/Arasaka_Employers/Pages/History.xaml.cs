﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Arasaka_Employers.UserControls;
using MySql.Data.MySqlClient;

namespace Arasaka_Employers.Pages
{
    /// <summary>
    /// Логика взаимодействия для History.xaml
    /// </summary>
    public partial class History : Page
    {
        private MySqlConnection con;
        public History(int? id)
        {
            con = new MySqlConnection(App.conString);
                InitializeComponent();
            if (id == null)
            {
                string Querry = "Select ID_Order from orders";
                con.Open();
                MySqlCommand command = new MySqlCommand(Querry, con);
                MySqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    Vitrina.Items.Add(new Orders(reader.GetInt32(0)));
                }
                con.Close();
            }
            else
            {
                Bt.Visibility = Visibility;
                string Querry2 = $"Select ID_Order from orders where Id_User={id}";
                con.Open();
                MySqlCommand command2 = new MySqlCommand(Querry2, con);
                MySqlDataReader reader2 = command2.ExecuteReader();
                while (reader2.Read())
                {
                    Vitrina.Items.Add(new Orders(reader2.GetInt32(0)));
                }
                con.Close();
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }
    }
}
