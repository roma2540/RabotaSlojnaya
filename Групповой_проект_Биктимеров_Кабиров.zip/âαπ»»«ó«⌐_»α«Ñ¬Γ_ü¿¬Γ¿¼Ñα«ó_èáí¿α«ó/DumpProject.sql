-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: localhost    Database: arasaka
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `categorys`
--

DROP TABLE IF EXISTS `categorys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorys` (
  `Id_category` int NOT NULL AUTO_INCREMENT,
  `Name_category` varchar(50) NOT NULL,
  PRIMARY KEY (`Id_category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorys`
--

LOCK TABLES `categorys` WRITE;
/*!40000 ALTER TABLE `categorys` DISABLE KEYS */;
INSERT INTO `categorys` VALUES (1,'Смартфон'),(2,'Телевизор'),(3,'Часы'),(4,'Клавиатура'),(5,'Наушники'),(6,'Планшет'),(7,'Монитор');
/*!40000 ALTER TABLE `categorys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_product`
--

DROP TABLE IF EXISTS `order_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_product` (
  `idOrder_product` int NOT NULL AUTO_INCREMENT,
  `ID_Product` int NOT NULL,
  `Conut` int NOT NULL,
  `Id_order` int NOT NULL,
  PRIMARY KEY (`idOrder_product`),
  KEY `O_idx` (`Id_order`),
  KEY `P_idx` (`ID_Product`),
  CONSTRAINT `O` FOREIGN KEY (`Id_order`) REFERENCES `orders` (`ID_Order`),
  CONSTRAINT `P` FOREIGN KEY (`ID_Product`) REFERENCES `products` (`Id_product`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_product`
--

LOCK TABLES `order_product` WRITE;
/*!40000 ALTER TABLE `order_product` DISABLE KEYS */;
INSERT INTO `order_product` VALUES (1,2,2,1),(2,3,1,1),(3,1,1,1),(4,9,1,1),(5,5,1,1),(6,2,1,2),(7,1,1,2),(8,4,1,2),(9,1,1,3),(10,2,1,3),(11,4,1,3),(12,3,3,3);
/*!40000 ALTER TABLE `order_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `ID_Order` int NOT NULL AUTO_INCREMENT,
  `Data` date NOT NULL,
  `Id_User` int NOT NULL,
  `Status` int NOT NULL,
  PRIMARY KEY (`ID_Order`),
  KEY `S_idx` (`Status`),
  KEY `u_idx` (`Id_User`),
  CONSTRAINT `S` FOREIGN KEY (`Status`) REFERENCES `status` (`idstatus`),
  CONSTRAINT `u` FOREIGN KEY (`Id_User`) REFERENCES `users` (`Id_User`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (1,'0000-00-00',2,2),(2,'0000-00-00',2,1),(3,'0000-00-00',2,1);
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `Id_product` int NOT NULL AUTO_INCREMENT,
  `Name_product` varchar(100) NOT NULL,
  `Description` varchar(600) NOT NULL,
  `Category` int NOT NULL,
  `Cost` int NOT NULL,
  `Count_product` int NOT NULL,
  `photo` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Id_product`),
  KEY `C_idx` (`Category`),
  CONSTRAINT `C` FOREIGN KEY (`Category`) REFERENCES `categorys` (`Id_category`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'Samsung Galaxy A33','\"Меньше значит больше. Galaxy A33 5G теперь тоньше и элегантнее. Матовый корпус с обновленной рамкой и узнаваемым блоком камер скрывает мощный функционал устройства.\n\"',1,19479,10,'samsung a 33.png'),(2,'Телевизор Samsung QE55Q80AAU QLED','\"Глубокий черный и естественный белый благодаря встроенной светодиодной матрице подсветки.\nТочно управляемая светодиодная подсветка большого количества зон на экране отображает самые глубокие оттенки черного и чистого белого.\"',2,105990,10,'televizor samsung.png'),(3,'Смартфон Samsung Galaxy A23','Откройте для себя больше возможностей, получите всё и сразу. 6,6-дюймовый PLS-дисплей Samsung Galaxy A23 с V-образным вырезом позволяет видеть и делать больше. ',1,14529,13,'samsung a 23.png'),(4,'Наручные часы Casio Collection','\"Новые яркие расцветки Винтажной коллекции часов.\nЯркие, полупрозрачные пластиковые часы водонепроницаемы, а их аккумулятор обеспечивает часы достаточным питанием приблизительно на семь лет.\"',3,2130,7,'casio.png'),(5,'Умный браслет Xiaomi Mi Band 7 CN','Новая версия популярного фитнес-браслета Xiaomi получила увеличенный 1,62-дюймовый цветной AMOLED дисплей с разрешением 490 х 192 пикселей — на 25% больше, чем у предыдущей модели линейки. Датчики ЧСС и SpO2, аккумулятор увеличенной до 180 мА·ч ёмкости, приёмник GPS и Zepp OS в качестве программной платформы.',3,2640,26,'xiaomi mi band.png'),(6,'Клавиатура CROWN MICRO CMGK-901 Outemu Brown','Механическая клавиатура TKL (без цифрового блока). Использованы качественные переключатели OUTEMU BROWN, с тактильной отдачей, но при этом значительно тише чем BLUE.',4,4129,19,'klava krown.png'),(7,'Клавиатура Logitech K380 Multi-Device','Logitech Keyboard K380 - это очень удобная в использовании, беспроводная клавиатура, способная подключаться, одновременно, к трём различным устройствам: будь то смартфон, планшет или персональный компьютер.',4,2669,10,'klava logitec.png'),(9,'Смартфон HUAWEI Nova 9 SE','Смартфон Huawei Nova 9 SE оснащен 6,78-дюймовым дисплеем с ультратонкими рамками (1,05 мм). Он выполнен по технологии LCD, обладает частотой обновления 90 Гц. Высокую производительность обеспечивают восьмиядерный процессор Qualcomm Snapdragon 680 и 8 Гб оперативной памяти. Есть встроенное хранилище объемом 128 Гб.',1,17969,7,'huavei.png'),(10,'Компьютерная гарнитура Razer Blackshark V2 X','\"Игровая гарнитура Razer Blackshark V2 X.\nЯркое звучание, чистый звук микрофона и отличное шумоподавление - всё это совмещает в себе игровая гарнитура Blackshark V2 X от Razer. А их небольшой вес и мягкие амбушюры и оголовье позволят носить их долгое время без какого-либо дискомфорта.\"',5,4390,15,'razer.png'),(11,'Беспроводные наушники Xiaomi Redmi Buds 3 Lite Global','\"Эргономичный дизайн обеспечивает комфорт и надежную посадку наушников Redmi Buds 3 Lite в ушах даже во время тренировок.\nАвтоматическое распознавание устройств и просто беспроводное подключение. Извлеките наушники из зарядного футляра и вставьте в уши. Вы услышите звук подключения, означающий, что устройство подключено к наушникам.\"',5,1359,25,'redmi buds.png'),(12,'Планшет Apple iPad 10.2 2021','Для работы. Для отдыха. Для творчества. Это iPad - универсальный и доступный планшет, прекрасно проявляющий себя во всех сферах: от создания музыки и видео до общения с друзьями и близкими. С iPad всегда все очень просто.',6,39990,6,'Ipad.png'),(13,'Планшет HUAWEI MatePad, 4 ГБ/128 ГБ','HUAWEI MatePad - . Яркий 2K дисплей с минимальными рамками. Тонкий корпус и скрытые антенны. Благодаря новому процессору HiSilicon Kirin 820, вы получите плавную работу интерфейса, быстрый отклик в приложениях и отличную автономность, а модуль искусственного интеллекта Da Vinci оптимизирует работу MatePad в соответствии с вашими сценариями использования HUAWEI Mate Pad способен работать до 12 часов.',6,23990,33,'mate pad.png'),(14,'Redmi Display RMMNT27NF','\"Широкоформатный монитор с высоким разрешением для работы, игр, просмотра фильмов и сериалов.\nДисплей с IPS-матрицей, разрешением Full HD 1080p и технологией защиты зрения подходит для работы и развлечений. Благодаря режиму низкого уровня синего света глаза не устают от многочасового сидения за монитором.\"',7,11980,11,'Display.png'),(15,'Проводная клавиатура KEYBOARD HIGH SPEED','\"Трехцветная красивая светодиодная подсветка  104 клавиши удовлетворяют всем требованиям использования Легкий корпус, удобный для ношения в любом вашем путешествии Подключи и играй, не нужно устанавливать драйвера, проста в использовании\nЭргономичный дизайн предназначен для геймеров и других пользователей\"',4,1680,32,'klaviatura high speed.png'),(16,'Sap','123',3,2000,200,'Cyberpunk-2077-PNG-HD-Quality-PNG-Background.png'),(17,'Телефон','123',1,12000,12,'unknown.png'),(18,'Еж','Ёжик',1,100000,1,'960.png');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `Id_role` int NOT NULL,
  `Role` varchar(45) NOT NULL,
  PRIMARY KEY (`Id_role`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'Админ'),(2,'Работник'),(3,'Клиент');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `status`
--

DROP TABLE IF EXISTS `status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `status` (
  `idstatus` int NOT NULL,
  `NameStat` varchar(45) NOT NULL,
  PRIMARY KEY (`idstatus`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `status`
--

LOCK TABLES `status` WRITE;
/*!40000 ALTER TABLE `status` DISABLE KEYS */;
INSERT INTO `status` VALUES (1,'Создан'),(2,'Принят ');
/*!40000 ALTER TABLE `status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `Id_User` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(50) NOT NULL,
  `Surname` varchar(50) NOT NULL,
  `Patronymic` varchar(50) DEFAULT NULL,
  `Login` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `Role` int NOT NULL,
  PRIMARY KEY (`Id_User`),
  KEY `roleId_idx` (`Role`),
  CONSTRAINT `Roles` FOREIGN KEY (`Role`) REFERENCES `roles` (`Id_role`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Ильнур','Биктимеров','Уралович','sap','123',1),(2,'Ваня ','Ваня','Ваня','s','s',3),(3,'sap1','aa','aa','aa','aa',2),(4,'Аврам','Аврамов','Аврамович','avram','ava',3);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-19  8:39:53
